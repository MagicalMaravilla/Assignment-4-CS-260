#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "Customer.h"

struct Node {
    Customer data;
    Node* next;
    Node(Customer data, Node* next = nullptr);
};

class LinkedList {
private:
    Node* head;
public:
    LinkedList();
    ~LinkedList();
    void add(const Customer& customer, int position);
    Customer remove(int position);
    Customer get(int position) const;
    void printList() const;
};

#endif // LINKED_LIST_H
