
README

Customer.h
Defines the Customer struct, encapsulating customer details like name, party size, orders, and preferences. Essential for managing customer information in restaurant scenarios.

LinkedList.h
Implements a linked list specifically for handling Customer objects. It provides functionality to add, remove, and retrieve customers at specific positions, crucial for dynamic customer management.

Order.h
Outlines the Order struct, which includes details about a customer's order, such as items and special notes. It's vital for tracking orders associated with customers.

RestaurantLinkedListTests.cpp
Contains tests for the linked list operations, making sure that adding, removing, and retrieving Customer objects works as expected. Demonstrates the linked list's functionality through practical scenarios.

ResturantArrayandLinks(ArrayFocus).cpp
show how to handl customer and order data, focusing on array-based implementations and their comparison or integration with linked list structures. Aims at showcasing different data structure applications within the same context.




