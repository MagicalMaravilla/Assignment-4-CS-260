#include <iostream>
#include <vector>
#include <string>
#include "LinkedList.h"

// Implement the Order constructor
Order::Order(const std::vector<std::string>& items, const std::string& notes) : items(items), notes(notes) {}

// Implement the default Customer constructor
Customer::Customer() : partySize(0), hasArrived(false) {}

// Implement the parameterized Customer constructor
Customer::Customer(const std::string& n, int pSize, const std::string& aTime, const std::string& sRequests, const std::vector<Order>& os, const std::string& cInfo, const std::string& sPreference, bool arrived)
: name(n), partySize(pSize), arrivalTime(aTime), specialRequests(sRequests), orders(os), contactInfo(cInfo), seatingPreference(sPreference), hasArrived(arrived) {}

// Implement the Node constructor
Node::Node(Customer data, Node* next) : data(data), next(next) {}

// Implement the LinkedList constructor
LinkedList::LinkedList() : head(nullptr) {}

// Implement the LinkedList destructor
LinkedList::~LinkedList() {
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
}

// Implement the add method for LinkedList
void LinkedList::add(const Customer& customer, int position) {
    if (position < 0) {
        std::cerr << "Invalid position.\n";
        return;
    }
    Node* newNode = new Node(customer);
    if (position == 0 || head == nullptr) {
        newNode->next = head;
        head = newNode;
    } else {
        Node* temp = head;
        for (int i = 0; temp != nullptr && i < position - 1; i++) {
            temp = temp->next;
        }
        if (temp == nullptr) {
            std::cerr << "Position out of bounds.\n";
            delete newNode;
            return;
        }
        newNode->next = temp->next;
        temp->next = newNode;
    }
}

// Implement the remove method for LinkedList
Customer LinkedList::remove(int position) {
    if (head == nullptr || position < 0) {
        std::cerr << "Invalid position or empty list.\n";
        return Customer(); // Return a default customer
    }
    Node* temp = head;
    Customer removedCustomer;
    if (position == 0) {
        head = temp->next;
        removedCustomer = temp->data;
        delete temp;
    } else {
        for (int i = 0; temp != nullptr && i < position - 1; i++) {
            temp = temp->next;
        }
        if (temp == nullptr || temp->next == nullptr) {
            std::cerr << "Position out of bounds.\n";
            return Customer(); // Return a default customer
        }
        Node* next = temp->next->next;
        removedCustomer = temp->next->data;
        delete temp->next;
        temp->next = next;
    }
    return removedCustomer;
}

// Implement the get method for LinkedList
Customer LinkedList::get(int position) const {
    Node* current = head;
    int count = 0;
    while (current != nullptr) {
        if (count == position) {
            return current->data;
        }
        count++;
        current = current->next;
    }
    std::cerr << "Position out of bounds.\n";
    return Customer(); // Return a default customer if not found
}

// Implement the printList method for LinkedList
void LinkedList::printList() const {
    Node* temp = head;
    while (temp != nullptr) {
        std::cout << "Customer Name: " << temp->data.name << ", Party Size: " << temp->data.partySize << std::endl;
        temp = temp->next;
    }
}

int main() {
    // Create a LinkedList instance
    LinkedList customerList;

    // Create some orders
    Order order1({ "Steak", "Wine" }, "Medium rare steak");
    Order order2({ "Salad" }, "No dressing");
    std::vector<Order> orders1 = {order1};
    std::vector<Order> orders2 = {order2};

    // Create some customers and add them to the list
    Customer customer1("Alice", 2, "19:00", "Near window", orders1, "555-0101", "Window", true);
    Customer customer2("Bob", 4, "19:30", "High chair needed", orders2, "555-0102", "Booth", true);

    customerList.add(customer1, 0); // Add Alice to the list
    customerList.add(customer2, 1); // Add Bob to the list

    // Print the customer list
    std::cout << "Customer List:" << std::endl;
    customerList.printList();

    // Remove a customer and print the list again
    customerList.remove(0);
    std::cout << "Customer List after removal:" << std::endl;
    customerList.printList();

    return 0;
}
