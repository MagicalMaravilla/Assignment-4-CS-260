#ifndef ORDER_H
#define ORDER_H

#include <vector>
#include <string>

struct Order {
    std::vector<std::string> items;
    std::string notes;
    Order(const std::vector<std::string>& items = {}, const std::string& notes = "");
};

#endif // ORDER_H
