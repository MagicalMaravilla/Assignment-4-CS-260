#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "Order.h"
#include <vector>
#include <string>

struct Customer {
    std::string name;
    int partySize;
    std::string arrivalTime;
    std::string specialRequests;
    std::vector<Order> orders;
    std::string contactInfo;
    std::string seatingPreference;
    bool hasArrived;

    Customer();
    Customer(const std::string& n, int pSize, const std::string& aTime, const std::string& sRequests, const std::vector<Order>& os, const std::string& cInfo, const std::string& sPreference, bool arrived);
};

#endif // CUSTOMER_H
