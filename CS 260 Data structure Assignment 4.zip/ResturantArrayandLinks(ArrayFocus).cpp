#include <iostream>
#include <vector>
#include <stdexcept> // Needed for exception handling

// Order structure as before
struct Order {
    std::vector<std::string> items;
    std::string notes;
    Order(const std::vector<std::string>& items, const std::string& notes = "") : items(items), notes(notes) {}
};

// Customer structure updated with a default constructor
struct Customer {
    std::string name;
    int partySize;
    std::string arrivalTime;
    std::string specialRequests;
    std::vector<Order> orders; // Now a vector of orders
    std::string contactInfo;
    std::string seatingPreference;
    bool hasArrived;

    // Adjust constructors as necessary
    Customer() : partySize(0), hasArrived(false) {}

    Customer(const std::string& n, int pSize, const std::string& aTime, const std::string& sRequests, const std::vector<Order>& os, const std::string& cInfo, const std::string& sPreference, bool arrived) 
    : name(n), partySize(pSize), arrivalTime(aTime), specialRequests(sRequests), orders(os), contactInfo(cInfo), seatingPreference(sPreference), hasArrived(arrived) {}
};

// Node structure for the linked list
struct Node {
    Customer data; // Holds the data for each node
    Node* next; // Pointer to the next node in the list
    Node(Customer data, Node* next = nullptr) : data(data), next(next) {} // Constructor
};

// Linked list class to manage nodes
class LinkedList {
private:
    Node* head; // Pointer to the first node in the list
public:
    LinkedList() : head(nullptr) {} // Constructor initializes the list as empty
    ~LinkedList(); // Destructor to free up memory
    void add(const Customer& customer, int position); // Add a customer at a position
    Customer remove(int position); // Remove a customer from a position
    Customer get(int position) const; // Get a customer without removing
    void printList() const; // Utility to print list contents for verification
};

// Destructor implementation to clear the list
LinkedList::~LinkedList() {
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
}

// Add function implementation
void LinkedList::add(const Customer& customer, int position) {
    if (position < 0) {
        throw std::out_of_range("Position must be positive");
    }
    if (position == 0 || head == nullptr) { // Adding at the head or to an empty list
        head = new Node(customer, head);
    } else {
        Node* temp = head;
        for (int i = 0; i < position - 1 && temp->next != nullptr; i++) {
            temp = temp->next; // Traverse to the position
        }
        Node* newNode = new Node(customer, temp->next); // Create and link new node
        temp->next = newNode;
    }
}

// Remove function implementation
Customer LinkedList::remove(int position) {
    if (head == nullptr) {
        throw std::out_of_range("List is empty");
    }
    Node* temp = head;
    Customer removedCustomer;
    if (position == 0) { // Removing from head
        head = head->next;
        removedCustomer = temp->data;
        delete temp;
    } else {
        Node* prev = nullptr;
        for (int i = 0; i < position && temp != nullptr; i++) {
            prev = temp;
            temp = temp->next; // Traverse to the position
        }
        if (temp == nullptr) {
            throw std::out_of_range("Position exceeds list size");
        }
        prev->next = temp->next; // Unlink the node
        removedCustomer = temp->data;
        delete temp;
    }
    return removedCustomer;
}

// Get function implementation
Customer LinkedList::get(int position) const {
    Node* temp = head;
    for (int i = 0; temp != nullptr && i < position; i++) {
        temp = temp->next; // Traverse to the position
    }
    if (temp == nullptr) {
        throw std::out_of_range("Position exceeds list size");
    }
    return temp->data; // Return the data without removing the node
}

// Utility function to print the list (for testing purposes)
void LinkedList::printList() const {
    Node* temp = head;
    while (temp != nullptr) {
        std::cout << temp->data.name << std::endl; // Print each customer's name
        temp = temp->next; // Move to the next node
    }
}

int main() {
    LinkedList restaurantList;

    // Correctly initialize Customer objects with a vector of Orders
    Customer customer1("John Doe", 2, "18:00", "No peanuts", {{{"Burger", "Fries"}, "Extra mayo"}}, "555-0100", "Window", true);
    Customer customer2("Jane Smith", 4, "18:30", "Vegan options", {{{"Veggie Pizza"}, ""}}, "555-0101", "Patio", true);
    Customer customer3("Alice Johnson", 3, "19:00", "High chair needed", {{{"Pasta", "Salad"}, "No onions"}}, "555-0102", "Booth", true);

    // Add customers to the list
    restaurantList.add(customer1, 0); // Add John Doe at position 0
    restaurantList.add(customer2, 1); // Add Jane Smith at position 1
    restaurantList.add(customer3, 2); // Add Alice Johnson at position 2

    std::cout << "Initial list of customers:" << std::endl;
    restaurantList.printList(); // Print list to see all customers

    // Remove a customer and show who was removed
    Customer removedCustomer = restaurantList.remove(1); // Remove the customer at position 1 (Jane Smith)
    std::cout << "\nRemoved customer: " << removedCustomer.name << std::endl;

    std::cout << "\nList after removal:" << std::endl;
    restaurantList.printList(); // Print list again to see the remaining customers

    // Get a customer's details without removing them
    Customer gotCustomer = restaurantList.get(1); // Get the customer at the new position 1 (Alice Johnson)
    std::cout << "\nCustomer at position 1: " << gotCustomer.name << std::endl;

    return 0;
}
